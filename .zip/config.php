<?php
$envFile = __DIR__ . '/.env';
if (file_exists($envFile)) {
    $lines = file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (str_starts_with(trim($line), '#')) continue;
        if (strpos($line, '=') !== false) {
            [$key, $value] = explode('=', $line, 2);
            $_ENV[trim($key)] = trim($value);
        }
    }
}

define('DB_HOST', $_ENV['DB_HOST'] ?? 'localhost');
define('DB_USER', $_ENV['DB_USER'] ?? 'root');
define('DB_PASS', $_ENV['DB_PASS'] ?? '');
define('DB_NAME', $_ENV['DB_NAME'] ?? 'tuapp');

define('DB_HOST_REMOTE', $_ENV['DB_HOST_REMOTE'] ?? '');
define('DB_USER_REMOTE', $_ENV['DB_USER_REMOTE'] ?? '');
define('DB_PASS_REMOTE', $_ENV['DB_PASS_REMOTE'] ?? '');
define('DB_NAME_REMOTE', $_ENV['DB_NAME_REMOTE'] ?? '');

define('GOOGLE_MAPS_API_KEY', $_ENV['GOOGLE_MAPS_API_KEY'] ?? '');
